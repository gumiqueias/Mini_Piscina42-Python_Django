name = "Gustavo"
age = 24
surname = "Miqueias"
profession = "Software Enginner"
